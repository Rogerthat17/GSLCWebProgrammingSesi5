<?php $__env->startSection('title', 'Web Programming'); ?>

<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $display): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php if($loop->even): ?>
<b> <?php echo e($key); ?>. <?php echo e($display['course']); ?> </b>
<div class="position-relative" style="background-color: #E98A02"> Material: <?php echo e($display['material']); ?> </div>
<div class="position-relative" style="background-color: #E98A02"> Code: <?php echo e($display['code']); ?> </div>
<div class="position-relative" style="background-color: #E98A02"> Class: <?php echo e($display['class']); ?> </div><br>



<?php else: ?>
<b> <?php echo e($key); ?>. <?php echo e($display['course']); ?> </b>
<div style="background-color: #2492D1"> Material: <?php echo e($display['material']); ?> </div>
<div style="background-color: #2492D1"> Code: <?php echo e($display['code']); ?> </div>
<div style="background-color: #2492D1"> Class: <?php echo e($display['class']); ?> </div><br>


<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p>No post found</p>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GSLCSesi5\resources\views/display/main.blade.php ENDPATH**/ ?>