<?php $__env->startSection('title', $post['title']); ?>

<?php $__env->startSection('content'); ?>

<?php if($post['is_new']): ?>
<div>A new blog post!</div>
<?php elseif(!$post['is_new']): ?>
<div>An old blog post!</div>
<?php else: ?>
<div>Monthly post</div>
<?php endif; ?>

<h1><?php echo e($post['course']); ?></h1>
<p><?php echo e($post['material']); ?></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GSLCSesi5\resources\views/posts/show.blade.php ENDPATH**/ ?>