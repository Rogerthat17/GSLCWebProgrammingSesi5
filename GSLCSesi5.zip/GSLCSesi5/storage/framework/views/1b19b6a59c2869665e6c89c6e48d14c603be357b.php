<?php $__env->startSection('title', 'Blog Posts'); ?>

<?php $__env->startSection('content'); ?>




<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>





<?php if($loop->even): ?>
<div class="position-relative"> <?php echo e($key); ?>. <?php echo e($post['title']); ?> </div>
<div class="position-relative"> <?php echo e($post['content']); ?> </div><br>



<?php else: ?>
<div style="background-color: silver"> <?php echo e($key); ?>. <?php echo e($post['title']); ?> </div>
<div style="background-color: silver"> <?php echo e($post['content']); ?> </div><br style="background-color: silver">


<?php endif; ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p>No post found</p>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GSLCSesi5\resources\views/posts/index.blade.php ENDPATH**/ ?>