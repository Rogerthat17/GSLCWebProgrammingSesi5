<?php $__env->startSection('title', 'Page Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>

<h1>List Mahasiswa</h1>
<p> diwdwijwojwod </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GSLCSesi5\resources\views/home/mahasiswa.blade.php ENDPATH**/ ?>