<?php $__env->startSection('title', 'HomePage'); ?>

<?php $__env->startSection('content'); ?>

<h1>Hello World</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GSLCSesi5\resources\views/home/index.blade.php ENDPATH**/ ?>